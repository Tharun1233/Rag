"""Source package for the RAG application."""
